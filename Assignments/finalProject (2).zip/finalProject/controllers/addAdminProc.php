<?php
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../classes/Pdo_methods.php';
require_once __DIR__ . '/../classes/StickyForm.php';

$sf = new StickyForm();

// 1) Build formConfig
$formConfig = [
  'name'     => [
    'id'=>'name','label'=>'Name','name'=>'name','type'=>'text',
    'regex'=>'name','value'=>$_POST['name']??'',
    'errorMsg'=>'Enter a valid name','required'=>true,'error'=>''
  ],
  'email'    => [
    'id'=>'email','label'=>'Email','name'=>'email','type'=>'text',
    'regex'=>'email','value'=>$_POST['email']??'',
    'errorMsg'=>'Enter a valid email','required'=>true,'error'=>''
  ],
  'password' => [
    'id'=>'password','label'=>'Password','name'=>'password','type'=>'password',
    'regex'=>'none','value'=>$_POST['password']??'',
    'errorMsg'=>'Enter a password','required'=>true,'error'=>''
  ],
  'status'   => [
    'id'=>'status','label'=>'Status','name'=>'status','type'=>'select',
    'regex'=>'none','value'=>$_POST['status']??'',
    'errorMsg'=>'Select a status','required'=>true,'error'=>'',
    'options'=>['staff'=>'staff','admin'=>'admin'],
  ],
];

// 2) Validate & re-show if errors
$formConfig = $sf->validateForm($_POST, $formConfig);
if (
    !empty($formConfig['name']['error'])
 || !empty($formConfig['email']['error'])
 || !empty($formConfig['password']['error'])
 || !empty($formConfig['status']['error'])
) {
    include __DIR__ . '/../views/addAdminForm.php';
    exit;
}

// 3) Hash the password before inserting
$plain = $formConfig['password']['value'];
$hash  = password_hash($plain, PASSWORD_DEFAULT);
$formConfig['password']['value'] = $hash;

// 4) Do the INSERT
$bindings = [];
foreach (['name','email','password','status'] as $key) {
    $cfg = $formConfig[$key];
    $bindings[] = [':'.$cfg['name'], $cfg['value'], 'str'];
}

$sql = "INSERT INTO admins (name,email,password,status)
        VALUES (:name,:email,:password,:status)";
$pdo = new Pdo_methods();
$res = $pdo->otherBinded($sql, $bindings);

// 5) Flash + redirect
$_SESSION['msg'] = [
  'type' => $res==='noerror' ? 'success' : 'danger',
  'text' => $res==='noerror' ? 'Admin added' : 'Could not add admin',
];
header('Location: index.php?page=addAdmin');
exit;
