<?php
// controllers/loginProc.php
// SESSION is already started in routes/router.php, so no session_start() here

require_once __DIR__ . '/../classes/Pdo_methods.php';

// 1) Collect & trim input
$email    = trim($_POST['email']    ?? '');
$password = trim($_POST['password'] ?? '');

// 2) Prepare error container
$errors = [];

// 3) Basic empty‐field checks
if ($email === '') {
    $errors['email'] = 'Please enter your email';
}
if ($password === '') {
    $errors['password'] = 'Please enter your password';
}

// 4) If any empty, re‐show the form
if (!empty($errors)) {
    include __DIR__ . '/../views/loginForm.php';
    exit;
}

// 5) Fetch the admin row by email
$pdo      = new Pdo_methods();
$sql      = "SELECT * FROM admins WHERE email = :email";
$bindings = [
    [':email', $email, 'str']
];
$rows = $pdo->selectBinded($sql, $bindings);

// 6) If query error or zero/too many rows, invalid credentials
if ($rows === 'error' || count($rows) !== 1) {
    $errors['login'] = 'Invalid credentials.';
    include __DIR__ . '/../views/loginForm.php';
    exit;
}

$user = $rows[0];

// 7) Verify the password against the hash
if (!password_verify($password, $user['password'])) {
    $errors['login'] = 'Invalid credentials.';
    include __DIR__ . '/../views/loginForm.php';
    exit;
}

// 8) Success! Save user info in session
$_SESSION['user'] = [
    'id'     => $user['id'],
    'name'   => $user['name'],
    'status' => $user['status']
];

// 9) Redirect to the welcome page
header('Location: index.php?page=welcome');
exit;
