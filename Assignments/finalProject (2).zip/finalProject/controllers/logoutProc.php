<?php
// Destroy everything and go back to the login screen
session_start();
$_SESSION = [];
session_destroy();

// Redirect to the login page
header('Location: index.php?page=login');
exit;
