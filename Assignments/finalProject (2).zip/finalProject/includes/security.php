<?php
// finalProject/includes/security.php

// 1) Ensure the session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2) Must be logged in
if (empty($_SESSION['user'])) {
    header('Location: index.php?page=login');
    exit;
}

// 3) Only admins may access addAdmin / deleteAdmins
$page = $_GET['page'] ?? '';
if (in_array($page, ['addAdmin','deleteAdmins'], true)
    && ($_SESSION['user']['status'] ?? '') !== 'admin'
) {
    header('Location: index.php?page=login');
    exit;
}
