<?php
// finalProject/routes/router.php
session_start();

$page = $_GET['page'] ?? 'login';

switch ($page) {

    // ──────────────────────────────────────
    // LOGIN (GET shows form, POST processes it)
    case 'login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            require __DIR__ . '/../controllers/loginProc.php';
        } else {
            require __DIR__ . '/../views/loginForm.php';
        }
        break;

    // ──────────────────────────────────────
    // LOGOUT (always POST or GET––destroys session then redirects)
    case 'logout':
        require __DIR__ . '/../controllers/logoutProc.php';
        break;

    // ──────────────────────────────────────
    // WELCOME (after successful login)
    case 'welcome':
        require __DIR__ . '/../views/welcomeForm.php';
        break;

    // ──────────────────────────────────────
    // ADD CONTACT
    case 'addContact':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            require __DIR__ . '/../controllers/addContactProc.php';
        } else {
            require __DIR__ . '/../views/addContactForm.php';
        }
        break;

    // ──────────────────────────────────────
    // DELETE CONTACT(S)
    case 'deleteContacts':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            require __DIR__ . '/../controllers/deleteContactProc.php';
        } else {
            require __DIR__ . '/../views/deleteContactsTable.php';
        }
        break;

    // ──────────────────────────────────────
    // ADD ADMIN (admin-only per security.php)
    case 'addAdmin':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            require __DIR__ . '/../controllers/addAdminProc.php';
        } else {
            require __DIR__ . '/../views/addAdminForm.php';
        }
        break;

    // ──────────────────────────────────────
    // DELETE ADMIN(S) (admin-only per security.php)
    case 'deleteAdmins':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            require __DIR__ . '/../controllers/deleteAdminProc.php';
        } else {
            require __DIR__ . '/../views/deleteAdminsTable.php';
        }
        break;

    // ──────────────────────────────────────
    // NOTHING MATCHED → go back to login
    default:
        header('Location: index.php?page=login');
        break;
}

// stop here
exit;
