<?php
// views/deleteAdminsTable.php

require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../classes/Pdo_methods.php';

// Fetch admins
$pdo    = new Pdo_methods();
$admins = $pdo->selectNotBinded("SELECT id, name, email FROM admins");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Delete Admin(s)</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

  <!-- single navbar -->
  <?php include __DIR__ . '/../includes/navigation.php'; ?>

  <div class="container py-4">
    <h1>Delete Admin(s)</h1>

    <form method="post" action="index.php?page=deleteAdmins">
      <?php if (empty($admins)): ?>
        <p>No administrators found.</p>
      <?php else: ?>
        <?php foreach ($admins as $admin): ?>
          <div class="form-check mb-2">
            <input 
              class="form-check-input"
              type="checkbox"
              name="ids[]" 
              value="<?= htmlspecialchars($admin['id']) ?>" 
              id="adm<?= htmlspecialchars($admin['id']) ?>">
            <label class="form-check-label" for="adm<?= htmlspecialchars($admin['id']) ?>">
              <?= htmlspecialchars($admin['name']) ?> &lt;<?= htmlspecialchars($admin['email']) ?>&gt;
            </label>
          </div>
        <?php endforeach; ?>

        <button type="submit" class="btn btn-danger mt-3">
          Delete Selected
        </button>
      <?php endif; ?>
    </form>
  </div>

</body>
</html>
