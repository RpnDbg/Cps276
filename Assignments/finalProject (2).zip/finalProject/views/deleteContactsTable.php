<?php
// views/deleteContactsTable.php

require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../classes/Pdo_methods.php';

// Fetch all contacts
$pdo      = new Pdo_methods();
$contacts = $pdo->selectNotBinded("SELECT id, fname, lname, email FROM contacts");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Delete Contact(s)</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

  <!-- single navbar -->
  <?php include __DIR__ . '/../includes/navigation.php'; ?>

  <div class="container py-4">
    <h1>Delete Contact(s)</h1>
    <form method="post" action="index.php?page=deleteContacts">
      <?php if (empty($contacts)): ?>
        <p>No contacts found.</p>
      <?php else: ?>
        <?php foreach ($contacts as $c): ?>
          <div class="form-check mb-2">
            <input
              class="form-check-input"
              type="checkbox"
              name="ids[]"
              value="<?= htmlspecialchars($c['id']) ?>"
              id="ct<?= htmlspecialchars($c['id']) ?>">
            <label class="form-check-label" for="ct<?= htmlspecialchars($c['id']) ?>">
              <?= htmlspecialchars($c['fname'] . ' ' . $c['lname']) ?> — <?= htmlspecialchars($c['email']) ?>
            </label>
          </div>
        <?php endforeach; ?>

        <button type="submit" class="btn btn-danger mt-3">
          Delete Selected
        </button>
      <?php endif; ?>
    </form>
  </div>

</body>
</html>
