<?php
require_once __DIR__ . '/Db_conn.php';

class Pdo_methods extends DatabaseConn {
    private PDOStatement $sth;
    private ?PDO         $conn = null;

    public function selectBinded(string $sql, array $bindings) {
        try {
            $this->db_connection();
            $this->sth = $this->conn->prepare($sql);
            $this->createBinding($bindings);
            $this->sth->execute();
        } catch (PDOException $e) {
            echo $e->getMessage();
            return 'error';
        }
        $this->conn = null;
        return $this->sth->fetchAll(PDO::FETCH_ASSOC);
    }

    public function selectNotBinded(string $sql) {
        try {
            $this->db_connection();
            $this->sth = $this->conn->prepare($sql);
            $this->sth->execute();
        } catch (PDOException $e) {
            echo $e->getMessage();
            return 'error';
        }
        $this->conn = null;
        return $this->sth->fetchAll(PDO::FETCH_ASSOC);
    }

    public function otherBinded(string $sql, array $bindings) {
        try {
            $this->db_connection();
            $this->sth = $this->conn->prepare($sql);
            $this->createBinding($bindings);
            $this->sth->execute();
        } catch (PDOException $e) {
            echo $e->getMessage();
            return 'error';
        }
        $this->conn = null;
        return 'noerror';
    }

    public function otherNotBinded(string $sql) {
        try {
            $this->db_connection();
            $this->sth = $this->conn->prepare($sql);
            $this->sth->execute();
        } catch (PDOException $e) {
            echo $e->getMessage();
            return 'error';
        }
        $this->conn = null;
        return 'noerror';
    }

    private function db_connection(): void {
        $this->conn = $this->dbOpen();
    }

    /**
     * Bind each param with bindValue so literals work correctly.
     * @param array $bindings Each entry: [':param', $value, 'str'|'int']
     */
    private function createBinding(array $bindings): void {
        foreach ($bindings as $b) {
            [$param, $val, $type] = $b;
            $pdoType = $type === 'int' ? PDO::PARAM_INT : PDO::PARAM_STR;
            $this->sth->bindValue($param, $val, $pdoType);
        }
    }
}
