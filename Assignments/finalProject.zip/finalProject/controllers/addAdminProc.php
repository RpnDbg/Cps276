<?php

require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../classes/Db_conn.php';
require_once __DIR__ . '/../classes/Pdo_methods.php';

$errors   = [];
$name     = trim($_POST['name']     ?? '');
$email    = trim($_POST['email']    ?? '');
$password = trim($_POST['password'] ?? '');
$status   = $_POST['status']        ?? '';

// 1) Basic validation
if ($name === '') {
    $errors['name'] = 'Name is required.';
}
if ($email === '') {
    $errors['email'] = 'Email is required.';
} elseif (! filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = 'Invalid email format.';
}
if ($password === '') {
    $errors['password'] = 'Password is required.';
}
if (! in_array($status, ['staff','admin'], true)) {
    $errors['status'] = 'Please select a status.';
}

// 2) If errors, show form again
if (! empty($errors)) {
    include __DIR__ . '/../views/addAdminForm.php';
    exit;
}

// 3) Check for duplicate email
$pdo  = new Pdo_methods();
$sql  = "SELECT id FROM admins WHERE email = :email";
$bind = [[ ':email', $email, 'str' ]];
$rows = $pdo->selectBinded($sql, $bind);
if ($rows !== 'error' && count($rows) > 0) {
    $errors['email'] = 'That email is already in use.';
    include __DIR__ . '/../views/addAdminForm.php';
    exit;
}

// 4) Insert new admin
$hash = password_hash($password, PASSWORD_DEFAULT);
$sql  = "INSERT INTO admins (name,email,password,status)
         VALUES (:name,:email,:password,:status)";
$bind = [
    [':name',     $name,     'str'],
    [':email',    $email,    'str'],
    [':password', $hash,     'str'],
    [':status',   $status,   'str'],
];

$res = $pdo->otherBinded($sql, $bind);
if ($res === 'noerror') {
    $_SESSION['msg'] = ['type'=>'success','text'=>'Admin added'];
} else {
    $_SESSION['msg'] = ['type'=>'danger','text'=>'Error adding admin'];
}

header('Location: index.php?page=addAdmin');
exit;
