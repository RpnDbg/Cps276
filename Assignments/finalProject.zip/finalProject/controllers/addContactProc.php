<?php

require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../classes/Pdo_methods.php';
require_once __DIR__ . '/../classes/StickyForm.php';
require_once __DIR__ . '/../classes/Validation.php';

// 1) Build the formConfig array
$formConfig = [
    'fname' => [
        'type'=>'text','regex'=>'name','label'=>'*First Name',
        'name'=>'fname','id'=>'fname','errorMsg'=>'Enter a valid first name',
        'error'=>'','required'=>true,'value'=>$_POST['fname']??''
    ],
    'lname' => [
        'type'=>'text','regex'=>'name','label'=>'*Last Name',
        'name'=>'lname','id'=>'lname','errorMsg'=>'Enter a valid last name',
        'error'=>'','required'=>true,'value'=>$_POST['lname']??''
    ],
    'address' => [
        'type'=>'text','regex'=>'address','label'=>'*Address',
        'name'=>'address','id'=>'address','errorMsg'=>'Enter a valid address',
        'error'=>'','required'=>true,'value'=>$_POST['address']??''
    ],
    'city' => [
        'type'=>'text','regex'=>'city','label'=>'*City',
        'name'=>'city','id'=>'city','errorMsg'=>'Enter a valid city',
        'error'=>'','required'=>true,'value'=>$_POST['city']??''
    ],
    'state' => [
        'type'=>'select','label'=>'*State','name'=>'state','id'=>'state',
        'errorMsg'=>'Select a state','error'=>'','required'=>true,
        'selected'=>$_POST['state']??'',
        'options'=>[
            '0'=>'Please Select','CA'=>'California','TX'=>'Texas',
            'MI'=>'Michigan','NY'=>'New York','FL'=>'Florida'
        ]
    ],
    'zip' => [
        'type'=>'text','regex'=>'zip','label'=>'*Zip Code',
        'name'=>'zip','id'=>'zip','errorMsg'=>'Enter 5-digit zip','error'=>'',
        'required'=>true,'value'=>$_POST['zip']??''
    ],
    'phone' => [
        'type'=>'text','regex'=>'phone','label'=>'*Phone',
        'name'=>'phone','id'=>'phone','errorMsg'=>'Format 999.999.9999',
        'error'=>'','required'=>true,'value'=>$_POST['phone']??''
    ],
    'email' => [
        'type'=>'text','regex'=>'email','label'=>'*Email',
        'name'=>'email','id'=>'email','errorMsg'=>'Enter valid email',
        'error'=>'','required'=>true,'value'=>$_POST['email']??''
    ],
    'dob' => [
        'type'=>'text','regex'=>'dob','label'=>'*DOB (mm/dd/yyyy)',
        'name'=>'dob','id'=>'dob','errorMsg'=>'Enter mm/dd/yyyy',
        'error'=>'','required'=>true,'value'=>$_POST['dob']??''
    ],
    'contacts' => [
        'type'=>'checkbox','label'=>'Contacts','name'=>'contacts',
        'id'=>'contacts','errorMsg'=>'','error'=>'','required'=>false,
        'options'=>[
            ['value'=>'Family','label'=>'Family','checked'=>false],
            ['value'=>'Friends','label'=>'Friends','checked'=>false],
            ['value'=>'Business','label'=>'Business','checked'=>false]
        ]
    ],
    'age' => [
        'type'=>'radio','label'=>'*Age Range','name'=>'age','id'=>'age',
        'errorMsg'=>'Select age range','error'=>'','required'=>true,
        'options'=>[
            ['value'=>'Under 18','label'=>'Under 18','checked'=>false],
            ['value'=>'18-30','label'=>'18 - 30','checked'=>false],
            ['value'=>'31-50','label'=>'31 - 50','checked'=>false],
            ['value'=>'50+','label'=>'50+','checked'=>false]
        ]
    ],
    'masterStatus'=>['error'=>false]
];

// 2) Validate
$sticky = new StickyForm();
$formConfig = $sticky->validateForm($_POST, $formConfig);

// 3) If errors, re-show form
if ($sticky->hasErrors() || $formConfig['masterStatus']['error']) {
    include __DIR__ . '/../views/addContactForm.php';
    exit;
}

// 4) Insert into DB
$pdo = new Pdo_methods();
$sql = "INSERT INTO contacts
  (fname,lname,address,city,state,zip,phone,email,dob,contacts,age)
  VALUES
  (:fname,:lname,:address,:city,:state,:zip,:phone,:email,
   STR_TO_DATE(:dob,'%m/%d/%Y'),:contacts,:age)";
$bind = [
    [':fname',$formConfig['fname']['value'],'str'],
    [':lname',$formConfig['lname']['value'],'str'],
    [':address',$formConfig['address']['value'],'str'],
    [':city',$formConfig['city']['value'],'str'],
    [':state',$formConfig['state']['selected'],'str'],
    [':zip',$formConfig['zip']['value'],'str'],
    [':phone',$formConfig['phone']['value'],'str'],
    [':email',$formConfig['email']['value'],'str'],
    [':dob',$formConfig['dob']['value'],'str'],
    [':contacts',implode(',',$_POST['contacts']??[]),'str'],
    [':age',$formConfig['age']['value']??'','str'],
];
$res = $pdo->otherBinded($sql,$bind);

$_SESSION['msg'] = $res==='noerror'
  ? ['type'=>'success','text'=>'Contact Information Added']
  : ['type'=>'danger','text'=>'Error adding record'];

header('Location: index.php?page=addContact');
exit;
