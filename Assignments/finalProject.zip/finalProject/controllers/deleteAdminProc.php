<?php

require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../classes/Db_conn.php';
require_once __DIR__ . '/../classes/Pdo_methods.php';

if (!empty($_POST['chkbx'])) {
    $pdo = new Pdo_methods();
    foreach ($_POST['chkbx'] as $id) {
        $pdo->otherBinded(
            "DELETE FROM admins WHERE id = :id",
            [[ ':id', (int)$id, 'int' ]]
        );
    }
    $_SESSION['msg'] = ['type'=>'success','text'=>'Admin(s) deleted'];
} else {
    $_SESSION['msg'] = ['type'=>'warning','text'=>'No admin selected'];
}

header('Location: index.php?page=deleteAdmins');
exit;
