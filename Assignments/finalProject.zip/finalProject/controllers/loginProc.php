<?php
// routes/router.php
session_start();

// Default to login if no page specified
$page = $_GET['page'] ?? 'login';

switch ($page) {
    case 'login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // process the submitted credentials
            require __DIR__ . '/../controllers/loginProc.php';
            // loginProc either redirects to welcome or re-includes loginForm.php
            exit;
        } else {
            // just show the blank login form
            require __DIR__ . '/../views/loginForm.php';
            exit;
        }

    case 'welcome':
        require __DIR__ . '/../views/welcomeForm.php';
        exit;

    case 'addContact':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            require __DIR__ . '/../controllers/addContactProc.php';
            exit;
        } else {
            require __DIR__ . '/../views/addContactForm.php';
            exit;
        }

    case 'deleteContacts':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            require __DIR__ . '/../controllers/deleteContactProc.php';
            exit;
        } else {
            require __DIR__ . '/../views/deleteContactsTable.php';
            exit;
        }

    // ... repeat for addAdmin/deleteAdmins if you have them ...

    default:
        // unknown page: redirect home
        header('Location: index.php?page=login');
        exit;
}
