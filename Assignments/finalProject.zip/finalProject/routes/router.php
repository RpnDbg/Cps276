<?php
session_start();

$content = ''; // default

// Which page?
$page = $_GET['page'] ?? 'login';

switch ($page) {
    case 'login':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // handle the submission
            require __DIR__ . '/../controllers/loginProc.php';
            // loginProc will redirect or re-include loginForm.php
            exit;
        } else {
            // show the blank login form
            require __DIR__ . '/../views/loginForm.php';
            exit;
        }

    case 'welcome':
        require __DIR__ . '/../views/welcomeForm.php';
        exit;

    // … your other cases …

    default:
        header('Location: index.php?page=login');
        exit;
}
