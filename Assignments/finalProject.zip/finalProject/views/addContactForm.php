<?php
session_start();
$msg = $_SESSION['msg'] ?? null;
unset($_SESSION['msg']);
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/navigation.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Add Contact</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet">
</head>
<body>
  <div class="container py-5">
    <h1>Add Contact</h1>

    <?php if ($msg): ?>
      <div class="alert alert-<?= $msg['type'] ?>">
        <?= htmlspecialchars($msg['text']) ?>
      </div>
    <?php endif; ?>

    <form method="post" action="index.php?page=addContact">
      <div class="row">
        <div class="col-md-6">
          <?= $sticky->renderInput($formConfig['fname'],'mb-3') ?>
        </div>
        <div class="col-md-6">
          <?= $sticky->renderInput($formConfig['lname'],'mb-3') ?>
        </div>
      </div>

      <?= $sticky->renderInput($formConfig['address'],'mb-3') ?>

      <div class="row">
        <div class="col-md-4">
          <?= $sticky->renderInput($formConfig['city'],'mb-3') ?>
        </div>
        <div class="col-md-4">
          <?= $sticky->renderSelect($formConfig['state'],'mb-3') ?>
        </div>
        <div class="col-md-4">
          <?= $sticky->renderInput($formConfig['zip'],'mb-3') ?>
        </div>
      </div>

      <div class="row">
        <div class="col-md-6">
          <?= $sticky->renderInput($formConfig['phone'],'mb-3') ?>
        </div>
        <div class="col-md-6">
          <?= $sticky->renderInput($formConfig['email'],'mb-3') ?>
        </div>
      </div>

      <?= $sticky->renderInput($formConfig['dob'],'mb-3') ?>
      <?= $sticky->renderCheckboxGroup($formConfig['contacts'],'mb-3','horizontal') ?>
      <?= $sticky->renderRadio($formConfig['age'],'mb-3','horizontal') ?>

      <button class="btn btn-primary">Add Contact</button>
    </form>
  </div>
</body>
</html>
