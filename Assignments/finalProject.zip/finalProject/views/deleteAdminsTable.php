<?php
session_start();
$msg = $_SESSION['msg'] ?? null;
unset($_SESSION['msg']);

require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/navigation.php';
require_once __DIR__ . '/../classes/Db_conn.php';
require_once __DIR__ . '/../classes/Pdo_methods.php';

$pdo     = new Pdo_methods();
$records = $pdo->selectNotBinded("SELECT * FROM admins");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Delete Admin(s)</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet" integrity="sha384-QWTKZy..."
    crossorigin="anonymous"
  >
</head>
<body>
  <div class="container py-5">
    <h1 class="mb-4">Delete Admin(s)</h1>

    <?php if($msg): ?>
      <div class="alert alert-<?= $msg['type'] ?>">
        <?= htmlspecialchars($msg['text']) ?>
      </div>
    <?php endif; ?>

    <?php if(empty($records)): ?>
      <p>There are no admins to display.</p>
    <?php else: ?>
      <form method="post" action="index.php?page=deleteAdmins">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Status</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($records as $r): ?>
            <tr>
              <td><?= htmlspecialchars($r['name']) ?></td>
              <td><?= htmlspecialchars($r['email']) ?></td>
              <td><?= htmlspecialchars($r['status']) ?></td>
              <td>
                <input type="checkbox" name="chkbx[]" value="<?= $r['id'] ?>">
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <button class="btn btn-danger">Delete Selected</button>
      </form>
    <?php endif; ?>
  </div>
</body>
</html>
