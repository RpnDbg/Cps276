<?php
require_once __DIR__ . '/../includes/security.php';
require_once __DIR__ . '/../includes/navigation.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Welcome</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
    crossorigin="anonymous"
  >
</head>
<body>
  <div class="container py-5">
    <h1>Welcome, <?= htmlspecialchars($_SESSION['user']['name']) ?></h1>
  </div>
</body>
</html>
